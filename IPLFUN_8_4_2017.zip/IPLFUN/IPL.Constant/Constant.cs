﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPL.Constant
{
    public static class Constant
    {
        public static string adminRoleId = "1";
        public static string userId = "3";
    }

  
}
